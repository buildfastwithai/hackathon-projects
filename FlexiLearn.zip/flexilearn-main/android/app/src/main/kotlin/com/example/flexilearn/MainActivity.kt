package com.example.flexilearn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
